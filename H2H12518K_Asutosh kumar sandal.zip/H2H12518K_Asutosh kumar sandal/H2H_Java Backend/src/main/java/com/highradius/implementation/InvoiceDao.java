package com.highradius.implementation;


import java.util.HashMap;
import java.util.List;

import com.highradius.model.Invoice;

public interface InvoiceDao {
	public HashMap<Object, Object> addInvoice(Invoice invoice) throws Exception;
	public HashMap<Object, Object> deleteInvoice(int sl_no) throws Exception;
	public HashMap<Object, Object> updateInvoice(Invoice invoice) throws Exception;
	public List<Invoice> AdvSearch(String customer_Order_Id,String sales_Org ,String distribution_Channel) throws Exception;
	public List<Invoice> searchInvoice(String customerOrderId)throws Exception;
	public List<Invoice> selectAllInvoice();
}
