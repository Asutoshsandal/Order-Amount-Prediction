package com.highradius.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	  private static  String jdbcURL = "jdbc:mysql://localhost:3307/hrc";
	  private static  String jdbcUsername = "root";
	  private static  String jdbcPassword = "Babuna@1234";
	
	   public static Connection getConn() { 
		   Connection conn=null;
		   try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
		}
		   catch(ClassNotFoundException | SQLException se) {
				System.out.println(se);
			}
			return conn;
	}
}
