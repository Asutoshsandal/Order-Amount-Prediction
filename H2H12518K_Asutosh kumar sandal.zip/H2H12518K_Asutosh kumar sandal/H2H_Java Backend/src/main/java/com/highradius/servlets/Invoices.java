package com.highradius.servlets;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;

import com.highradius.implementation.InvoiceDao;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.Invoice;

@WebServlet("/")
public class Invoices extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private InvoiceDao invoicedao;
	public void init() {
		invoicedao=new InvoiceDaoImpl();
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action=request.getServletPath();
	
		switch(action) {
		
		case"/addInvoice":
			try {
				addInvoice(request,response);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			break;
			
		 case "/deleteInvoice":
			try {
				deleteInvoice(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			
		 case "/updateInvoice":
				try {
					updateInvoice(request, response);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case "/AdvSearch":
				try {
					AdvSearch(request,response);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "/searchInvoice":
				try {
					searchInvoice(request,response);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				break;
			default:
				try {
					allInvoice(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
		}
	}
	private void searchInvoice(HttpServletRequest r, HttpServletResponse response) throws Exception {
		String cust_Id=r.getParameter("customer_Order_Id");
		Gson gson=new Gson();
		List<Invoice> invoice=invoicedao.searchInvoice(cust_Id);
		String jsonResponse = gson.toJson(invoice);
		PrintWriter printWriter=response.getWriter(); 
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Headers", "content-type");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		printWriter.write(jsonResponse);
		printWriter.close();
	}
	
				private void addInvoice(HttpServletRequest r, HttpServletResponse response) throws Exception {
				     int customer_Order_Id,sales_Org,company_Code,customer_Number;
				     String distribution_Channel,order_Currency;
				     double amount_In_Usd,order_Amount;
				     String order_Creation_Date;
					 
				//System.out.println(r);
				     
				     customer_Order_Id=Integer.parseInt(r.getParameter("customer_Order_Id"));
				     sales_Org=Integer.parseInt(r.getParameter("sales_Org"));
				     company_Code=Integer.parseInt(r.getParameter("company_Code"));
				     customer_Number=Integer.parseInt(r.getParameter("customer_Number"));
				     distribution_Channel=r.getParameter("distribution_Channel");
				     order_Currency=r.getParameter("order_Currency");
				     order_Creation_Date=r.getParameter("order_Creation_Date");
				     amount_In_Usd=Double.parseDouble(r.getParameter("amount_In_Usd"));
				     order_Amount=0;
				     
				
				     Invoice invoice=new Invoice(customer_Order_Id,sales_Org,company_Code,customer_Number,distribution_Channel,
								order_Currency,amount_In_Usd,order_Amount,order_Creation_Date);
			
				Gson gson=new Gson();
			
				String invoiceJSON=gson.toJson(invoice);
			
				System.out.println(invoiceJSON);
			
				String jsonResponse = gson.toJson(invoicedao.addInvoice(invoice));
				//response.getWriter().append(jsonResponse);
				
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				response.setHeader("Access-Control-Allow-Origin", "*");
				response.setHeader("Access-Control-Allow-Headers", "content-type");
				out.print(jsonResponse);
				out.flush();   
			
			}
      private void allInvoice(HttpServletRequest request, HttpServletResponse response) throws Exception
  	{
	   List<Invoice> allInvoice=invoicedao.selectAllInvoice();
	    Gson gson=new Gson();
		String recordJSON=gson.toJson(allInvoice);
		PrintWriter printWriter=response.getWriter();
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setHeader("Access-Control-Allow-Headers", "content-type");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		printWriter.write(recordJSON);
		printWriter.close();
  	}

              private void deleteInvoice(HttpServletRequest r, HttpServletResponse response) throws Exception {
			int s=Integer.parseInt(r.getParameter("sl_no"));
			System.out.println(s);
			
			Gson gson=new Gson();
		
			
			String jsonResponse = gson.toJson(invoicedao.deleteInvoice(s));
			//response.getWriter().append(jsonResponse);
		
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Headers", "content-type");
			out.print(jsonResponse);
			out.flush();   
		
		}
         private void AdvSearch(HttpServletRequest r, HttpServletResponse response) throws Exception {
			String cust_Id=r.getParameter("customer_Order_Id");
			String S_org=r.getParameter("sales_Org");
			String Dist_Channel=r.getParameter("distribution_Channel");
			Gson gson=new Gson();
			List<Invoice> sInvoices=invoicedao.AdvSearch(cust_Id,S_org,Dist_Channel);
			String jsonResponse = gson.toJson(sInvoices);
			PrintWriter printWriter=response.getWriter(); 
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Headers", "content-type");
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			printWriter.write(jsonResponse);
			printWriter.close();
		}
         private void updateInvoice(HttpServletRequest r, HttpServletResponse response) throws Exception {
		   int customer_Order_Id,sales_Org,company_Code,customer_Number;
		     String distribution_Channel,order_Currency;
		     double amount_In_Usd,order_Amount;
		     String order_Creation_Date;
		     
		     int sl_no=Integer.parseInt(r.getParameter("sl_no"));
		     customer_Order_Id=Integer.parseInt(r.getParameter("customer_Order_Id"));
		     sales_Org=Integer.parseInt(r.getParameter("sales_Org"));
		     company_Code=Integer.parseInt(r.getParameter("company_Code"));
		     customer_Number=Integer.parseInt(r.getParameter("customer_Number"));
		     distribution_Channel=r.getParameter("distribution_Channel");
		     order_Currency=r.getParameter("order_Currency");
		     amount_In_Usd=Double.parseDouble(r.getParameter("amount_In_Usd"));
		     order_Amount=Double.parseDouble(r.getParameter("order_Amount"));
		     order_Creation_Date=null;
			//System.out.println(r);
			
	
		     Invoice invoice=new Invoice(sl_no,customer_Order_Id,sales_Org,company_Code,customer_Number,distribution_Channel,
						order_Currency,amount_In_Usd,order_Amount,order_Creation_Date);
			Gson gson=new Gson();
	
			String recordJSON=gson.toJson(invoice);
	
			System.out.println(recordJSON);
	
			String jsonResponse = gson.toJson(invoicedao.updateInvoice(invoice));
			//response.getWriter().append(jsonResponse);
	
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Access-Control-Allow-Origin", "http://localhost:3000/");
			response.setHeader("Access-Control-Allow-Headers", "content-type");
			out.print(jsonResponse);
			out.flush();   
	
		}

	
	

}
