import React from 'react';
import ToolBar from '@mui/material/Toolbar';
import { AppBar, colors } from "@mui/material";
import lg from './hrclogo.svg';
import lg1 from './abclogo.svg';


var classes={
    logoCenter:{
      position: 'absolute', 
      left: '50%', 
      top: '70%',
      transform: 'translate(-50%, -50%)'
    },
    logo1:{
      transform: 'translate(-15px)',
      
    },
  };
const Header = () => {

    return( 
        <React.Fragment>
          

            <AppBar position='static' sx={{ minHeight:'10px', background : "white"}}>
                <ToolBar>
                <div style={classes.logoCenter}>
                  <img src={lg} alt=""/>
                </div>
                <div style={classes.logo1}>
                  <img src={lg1} alt=""/>
                </div>
                </ToolBar>
                <div >
                <h2
                 style={{
                 color: "red",
                 marginLeft:10,
                 fontSize: "15px",
                 marginTop:0
                 }}
               >
                 Invoice List
                </h2>
                </div>
        
            </AppBar>
  
        </React.Fragment>
    );
};

export default Header;













/*import React, { Component } from "react";
import hrclogo from "./hrclogo.svg";
import abclogo from "./abclogo.svg";

class Navbar extends Component {
  render() {
    return (
      <React.Fragment>
        <div
          style={{
            width: "100%",
          }}
        >
          <div className="container" align="center">
            <img
              src={abclogo}
              width="200"
              align="left"
              style={{marginTop: 10 }}
              alt=""
            />
            <img
              src={hrclogo}
              align="center"
              style={{ marginRight:"14%",marginTop: 10 }}
              alt=""
            />
          </div>
          <h2
            style={{
              color: "red",
              marginLeft: 10,
              fontSize: "20px",
              marginTop:0
            }}
          >
            Invoice List
          </h2>
        </div>
      </React.Fragment>
    );
  }
}
export default Navbar;*/