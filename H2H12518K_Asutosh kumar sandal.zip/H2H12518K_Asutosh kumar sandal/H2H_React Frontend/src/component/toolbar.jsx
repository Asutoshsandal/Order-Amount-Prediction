import React, { Component } from "react";
import Tab from '@mui/material/Tab';
import Stack from '@mui/material/Stack';
function a11yProps(index) {
  return {
    id: `action-tab-${index}`,
    'aria-controls': `action-tabpanel-${index}`,
  };
}
class Toolbar extends Component {
  state = {
    searchValue: "",
  };
  render() {
    return (
      <div
        style={{
          backgroundColor: "#2d4250",
          paddingLeft: 5,
        }}
        className="flex-container"
      >
        <Stack direction="row" spacing={2} position={"absolute"}  left={0} backgroundColor="#2d4250" color={"white"}>
        <Tab label="HOME" {...a11yProps(0)}/>
        <Tab label="ADD DATA" {...a11yProps(1)}  className="btn btn-default mx-2" onClick={this.props.addDataHandler}/>
        <Tab label="ANALYTICS VIEWS" {...a11yProps(2)}/>
        </Stack>
        <Stack direction="row" spacing={2} position={"absolute"}  right={0}>
        <form className="Search" onSubmit={this.props.submitHandler}>
          <input
            type="text"
            name="name"
            placeholder="Search Customer Order ID"
            onChange={this.props.searchHandler}
          />
        <input type="submit" className="btn btn-default" />
        </form>
        <button
          className="btn btn-advsearch mx-2"
          onClick={this.props.advSearchHandler}
           >
          Advance Search
        </button>
        </Stack>
        <div direction="row" style={{padding:10}}>
        <button className="btn btn-default mx-2"
        disabled={this.props.selectedRows.length === 1 ? "" : "+true"}
        onClick={this.props.predictDataHander}
        >Predict</button>
        <button
          className="btn btn-default mx-2"
          onClick={this.props.refreshHandler}
        >
          Refresh
        </button>
        <button
          disabled={this.props.selectedRows.length === 1 ? "" : "+true"}
          className="btn btn-default mx-2"
          onClick={this.props.editDataHander}
        >
          Edit
        </button>
        <button
          disabled={this.props.selectedRows.length === 1 ? "" : "+true"}
          className="btn btn-default mx-2"
          onClick={this.props.deleteDataHandler}
        >
          Delete
        </button>
        </div>
        </div>
    );
  }
}

export default Toolbar;
