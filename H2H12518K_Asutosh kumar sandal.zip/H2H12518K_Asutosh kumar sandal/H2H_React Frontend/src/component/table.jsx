import * as React from "react"; 
import { DataGrid } from "@mui/x-data-grid";
import Box from "@mui/material/Box";
import Stack from '@mui/material/Stack';
import { getData, keys } from "../data";
import { useState } from "react";
import { useEffect } from "react";
import { Hidden } from "@mui/material";
export default function Table({ selectedRows, selectRow }) {
  const [data, setData] = useState([]);
  useEffect(async () => {
    setData(await getData());
  }, []);
  const columns = [
    {
        field: "sl_no",
        headerName: "Sl No",
        width: 50,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "customer_Order_Id",
        headerName: "Customer Order Id",
        width: 100,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "sales_Org",
        headerName: "Sales Org",
        width: 100,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "company_Code",
        headerName: "Company Code",
        width: 120,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "customer_Number",
        headerName: "Customer Number",
        width: 140,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "distribution_Channel",
        headerName: "Distribution Channel",
        width: 300,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "order_Currency",
        headerName: "Order Currency",
        width: 150,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "order_Creation_Date",
        headerName: "Order Creation Date",
        width: 150,
        headerClassName: "super-app-theme--header",
      },
      {
        field: "amount_In_Usd",
        headerName: "Amount In Usd",
        width: 150,
        headerClassName: "super-app-theme--header",
        
      },
  
      {
        field: "order_Amount",
        headerName: "Order Amount",
        width: 150,
        headerClassName: "super-app-theme--header",
       
      },
  ];
  const rows = data;
  console.log("table data", data);
  return (
    <div style={{ height: 420, width: "100%", position:"sticky"}}>
      <Box
        sx={{
          height: "100%",
          width: 1,
          "& .super-app-theme--header": {
            backgroundColor: " #5A5A5A",
            color: "#ffffff",
          },
          backgroundColor: "#5A5A5A",
        }}
      >
        <DataGrid 
          rows={rows}
          columns={columns}
          rowsPerPageOptions={[5,10,20,50,100]}
          checkboxSelection
          getRowId={(row) => row.sl_no}
          selectionModel={selectedRows.map((e) => e.sl_no)}
          onSelectionModelChange={(ids) => {
          selectRow(rows.filter((e) => ids.indexOf(e.sl_no) != -1));
          }}
          sx={{
            "& .MuiToolbar-root": {
              color: "#ffffff",
            },
            border: "none",
            backgroundColor: "#5A5A5A",
            color: "#ffffff",
            "& .MuiDataGrid-columnSeparator--sideRight": {
              display: "none",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              color: "#ffffff",

              textOverflow: "clip",
              whiteSpace: "break-spaces",
              lineHeight: 1,
            },
          }}
        />
      </Box>
    </div>
  );
  
}